/*
 * OdometryCorrection.java
 */
package ca.mcgill.ecse211.odometer;

import lejos.hardware.Sound;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.robotics.Color;
import lejos.robotics.SampleProvider;

public class OdometryCorrection implements Runnable {
  private static final long CORRECTION_PERIOD = 10;
  private Odometer odometer;


	// constructor
	EV3ColorSensor colorSensor;
	SampleProvider colorSample;
	private float[] colorData;
	
	 // Initialize the sensor
	public OdometryCorrection(Odometer odometer) {
		Port sensorPort = LocalEV3.get().getPort("S3");
		this.odometer = odometer;
		colorSensor = new EV3ColorSensor(sensorPort);
		colorSample = colorSensor.getRedMode();
		this.colorData = new float[colorSensor.sampleSize()];		
	}

	
	
  
  /**
   * This is the default class constructor. An existing instance of the odometer is used. This is to
   * ensure thread safety.
   * 
   * @throws OdometerExceptions
   */
  public OdometryCorrection() throws OdometerExceptions {

    this.odometer = Odometer.getOdometer();

  }

  /**
   * Here is where the odometer correction code should be run.
   * 
   * @throws OdometerExceptions
   */
  // run method (required for Thread)
  public void run() {
    long correctionStart, correctionEnd;
    colorSensor.setFloodlight(Color.RED);
	
     // List of variables
	double LINE_LIGHT = 0.3;
	double tileDistance= 30.48;
	int xLines=0; // number of lines detected in positive x-axis
	int yLines=0; // number of lines detected in positive y-axis
	double delY = 0; // distance between starting point and first line detected in y-axis
	double delX =0; // distance between starting point and first line detected in x-axis
	double yHigh=0; // highest value of y
	double xHigh=0; // highest value of x
	int yLineCheck=0; // keeps track of the highest number of lines crossed in y-axis
	int xLineCheck=0; // keeps track of highest number of lines crossed in x-axis

    while (true) {
      correctionStart = System.currentTimeMillis();

      // TODO Trigger correction (When do I have information to correct?)
      colorSample.fetchSample(colorData, 0);
      
       // If the color sample corresponds to a line
      if (colorData[0] <= LINE_LIGHT) {
    	  	double[] position = null;
    	  	
    	  	 // Get the position of the robot
    	  	position = odometer.getXYT();
			double theta = position[2];
			
			
			if (theta <=75 || theta >358){ //checks whether the angel close to 0 degree with some room for error
				Sound.beep(); // makes one beep when crossing a line at positive y-axis
				if (yLines==0){ // If it's the first line in the y direction
					delY= position[1];
					odometer.setY(0);// the first line is y =0
				}
				else if (yLines>0){ // Second line and more in the y direction
					odometer.setY(tileDistance*yLines); //update the value of Y with the line it crosses
					
				}
				yLines++;  
				yLineCheck=yLines; //update yLineCheck
			}
			else if (theta>=85 && theta <=160){  //checks whether the angel close to 90 degree with some room for error
				Sound.beep(); // makes one beep when crossing a line at positive x-axis
				//System.out.println("y1");
				if (xLines==0){ // If it's first line in x direction
					delX= position[0]; 
					yHigh= position[1]; // y should be max
					odometer.setX(0); //the first line is x=0
				}
				else if (xLines>0){ // Second line and more in the y direction
					odometer.setX(tileDistance*xLines); //update the value of X with the line it crosses
					
				}
				xLines++;
				xLineCheck=xLines; //update xLineCheck
			}
			else if (theta>= 161 && theta<= 245){ //checks whether the angel close to 180 degree with some room for error
				Sound.beep(); // makes one beeps when crossing a line at negative y-axis
				//System.out.println("y2");
				if (yLines==yLineCheck){ //checks if its the first line while going down the y axis
					delY=yHigh - position[1]; //difference between the actual Y and the wanted Y
					xHigh= position[0]; // x should be max
				}
				else if(yLines != yLineCheck){ 
					odometer.setY(yHigh-delY-(yLineCheck-yLines)*tileDistance);	//update the value of Y with the line it crosses
					
				}
				yLines--;
			}
			else if (theta>=246 && theta <= 358){ // checks whether the angle is close to 270 degree with some room for error
				Sound.beep(); // makes one beep when crossing a line at negative x-axis
				//System.out.println("y3");
				if (xLines==xLineCheck){ //checks if its the first line while going down x axis
					delX= xHigh-position[0]; //difference between the actual X and the wanted X
				}
				else if (xLines != xLineCheck){ 
					odometer.setX(xHigh-delX-(xLineCheck-xLines)*tileDistance);  //update the value of X with the line it crosses
					
				}
				
				xLines--;
			}
			
		}


      // this ensure the odometry correction occurs only once every period
      correctionEnd = System.currentTimeMillis();
      if (correctionEnd - correctionStart < CORRECTION_PERIOD) {
        try {
          Thread.sleep(CORRECTION_PERIOD - (correctionEnd - correctionStart));
        } catch (InterruptedException e) {
          // there is nothing to be done here
        }
      }
    }
  }
}
