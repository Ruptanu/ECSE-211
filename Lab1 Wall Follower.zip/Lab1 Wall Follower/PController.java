package ca.mcgill.ecse211.wallfollowing;

import lejos.hardware.motor.EV3LargeRegulatedMotor;

/**
 * This class implements the p-controller, where the turning speed varies with the distance from the wall.
 * @author fd21h
 *
 */

public class PController implements UltrasonicController {

	/* Constants */
	private static final int MOTOR_SPEED = 200;
	private static final int FILTER_OUT = 20;
	//private static double propConstLeft=10.0;
//	private static double propConstRight=1.0;
	private static final int maxCorrection=100;
	private int bandCenter;
	private final int bandWidth;
	private int distance;
	private int filterControl;

	public PController(int bandCenter, int bandwidth) {
		this.bandCenter = bandCenter;
		this.bandWidth = bandwidth;
		this.filterControl = 0;

		WallFollowingLab2.leftMotor.setSpeed(MOTOR_SPEED); // Initalize motor rolling forward
		WallFollowingLab2.rightMotor.setSpeed(MOTOR_SPEED);
		WallFollowingLab2.leftMotor.forward();
		WallFollowingLab2.rightMotor.forward();
	}

	@Override
	
	/**
	 * The actual distance from the wall is calculated and the robot will turn at a turning speed relative to that distance.
	 */
	
	public void processUSData(int distance) {
		int angledistance = (int) (distance*0.74);
		// rudimentary filter - toss out invalid samples corresponding to null
		// signal.
		// (n.b. this was not included in the Bang-bang controller, but easily
		// could have).
		//
		if (distance >= 80 && filterControl < FILTER_OUT) {
			// bad value, do not set the distance var, however do increment the
			// filter value
			filterControl++;
		} else if (distance >= 80) {
			// We have repeated large values, so there must actually be nothing
			// there: leave the distance alone
			this.distance = distance;
			WallFollowingLab2.rightMotor.setSpeed(225);   
			WallFollowingLab2.leftMotor.setSpeed(85);    
			WallFollowingLab2.leftMotor.forward();
			WallFollowingLab2.rightMotor.forward();
		} else {
			// distance went below 80: reset filter and leave
			// distance alone.
			filterControl = 0;
			this.distance = distance;
		}

		// TODO: process a movement based on the us distance passed in (P style)
		int speed= MOTOR_SPEED;
		bandCenter=22; 
		int distError= bandCenter - angledistance;
		int diff;
		if (Math.abs(distError) <= bandWidth) {
			WallFollowingLab2.leftMotor.setSpeed(speed);
			WallFollowingLab2.rightMotor.setSpeed(speed);
			WallFollowingLab2.leftMotor.forward();
			WallFollowingLab2.rightMotor.forward();
		}
		else if ( distError> 0 && distError<=20){ // when its close 
			diff= calcProp(distError);
			WallFollowingLab2.leftMotor.setSpeed(speed+diff);
			WallFollowingLab2.rightMotor.setSpeed(speed);
			WallFollowingLab2.rightMotor.backward();
			WallFollowingLab2.leftMotor.forward();
		}
		else if (distError> 5){ //when its too close go back
			WallFollowingLab2.rightMotor.setSpeed(500);
			WallFollowingLab2.leftMotor.setSpeed(500);
			WallFollowingLab2.leftMotor.backward();
			WallFollowingLab2.rightMotor.backward();
		}
		else if ( distError<0) { // when its far
			diff= calcProp(distError);
			WallFollowingLab2.leftMotor.setSpeed(speed);
			WallFollowingLab2.rightMotor.setSpeed(2*diff+speed);
			WallFollowingLab2.leftMotor.forward();
			WallFollowingLab2.rightMotor.forward();
		}


	}
	
	/**
	 * This method calculates a speed depending on the distance from the wall.
	 * @param diff
	 * @return
	 */
	public int calcProp (int diff){
		double propconst= 4;
		int correction; 
		if (diff<0) diff=-diff;
		//if (diff<-50) propconst=1.1;
		correction=(int) (propconst*(double)diff);
		if (correction>=MOTOR_SPEED) correction= maxCorrection;
		return correction;

	}


	@Override
	public int readUSDistance() {
		return this.distance;
	}

}
