package ca.mcgill.ecse211.wallfollowing;

import lejos.hardware.motor.*;

/** 
 * This class implements the bang-bang controller, where the robot will turn at a set speed depending on its distance from the wall.
 * @author fd21h
 *
 */

public class BangBangController implements UltrasonicController {
	//unlike the pController, the bang bang controller does not adjust based on error. 
	//Instead, the BB controller has thresholds, over and under which, it will correct error at fixed values

	private final int bandCenter;		//distance from wall
	private final int bandwidth;
	private final int motorLow;
	private final int motorHigh;
	private int distance;
	private int filterControl;
	private static final int FILTER_OUT = 20;

	public BangBangController(int bandCenter, int bandwidth, int motorLow, int motorHigh) {
		// Default Constructor
		this.bandCenter = bandCenter;
		this.bandwidth = bandwidth;
		this.motorLow = motorLow;
		this.motorHigh = motorHigh;
		WallFollowingLab2.leftMotor.setSpeed(motorHigh); // Start robot moving straight forward
		WallFollowingLab2.rightMotor.setSpeed(motorHigh);
		WallFollowingLab2.leftMotor.forward();
		WallFollowingLab2.rightMotor.forward();
	}

	@Override

	/**
	 * The actual distance from the wall is calculated and the robot turns with one of the 4 different speeds depending on its distance from the wall.
	 */
	public void processUSData(int distance) {
		this.distance = distance;
		int angledistance = (int) (distance*0.74 ); // The sensor is not straight in front of the robot
													// so we take into consideration the angle and took the cosine
													// to get the actual distance between the sensor and the robot
		int delta = 25;		// Arbitrary value

		if (distance >= 255 && filterControl < FILTER_OUT) { // Used a filter in order not to use the bad coordinates
															 // This is the same filter that was given for PController.java
			filterControl++;
		} else if (distance >= 255) {
																// We have repeated large values, so there must actually be nothing
																// there: leave the distance alone
			this.distance = distance;
		} else {
																// distance went below 255: reset filter and leave
																// distance alone.
			filterControl = 0;
			this.distance = distance;
		}

		int distError = bandCenter - angledistance;          // the difference between the
													         // reference control value and
													         // measured distance from the wall

		if (Math.abs(distError) <= bandwidth) {                        // The robot is a good distance away from the wall so go straight
			WallFollowingLab2.leftMotor.setSpeed(motorHigh);
			WallFollowingLab2.rightMotor.setSpeed(motorHigh);
			WallFollowingLab2.leftMotor.forward();
			WallFollowingLab2.rightMotor.forward();
			
		} else if (distError > 0 && distError <= 12) {                  // When the robot gets close to the wall
			WallFollowingLab2.leftMotor.setSpeed(motorHigh + 5*delta);	// Make the left wheel go fast to make it turn fast
																		// (the sensor is to the left of the robot)
			WallFollowingLab2.rightMotor.setSpeed(motorLow - 50);       
			WallFollowingLab2.leftMotor.forward();
			WallFollowingLab2.rightMotor.forward();
	
		}else if (distError > 12) {                                        //the robot is way too close to the wall
			WallFollowingLab2.rightMotor.setSpeed(motorLow); 
			WallFollowingLab2.leftMotor.setSpeed(motorHigh + 3*delta);
			WallFollowingLab2.rightMotor.backward();                         // Setting it to go backwards in order to make the robot do a sharp turn
			WallFollowingLab2.leftMotor.forward();
		
		}else if (distError < 0  && distError >= -12) {                    // The robot is far from the wall
			WallFollowingLab2.leftMotor.setSpeed(motorLow); 
			WallFollowingLab2.rightMotor.setSpeed(motorHigh + 3*delta);	
			WallFollowingLab2.leftMotor.forward();
			WallFollowingLab2.rightMotor.forward();	
		
		}else if (distError < -12) {                                // The distance is very big but we need the robot to be slow to perform turns,
									                           // when the robot goes too fast, it can't register the new distance from the wall
									                            // and often crashes in the walls
			WallFollowingLab2.leftMotor.setSpeed(motorLow-30);
			WallFollowingLab2.rightMotor.setSpeed(motorHigh + 2*delta);
			WallFollowingLab2.leftMotor.forward();
			WallFollowingLab2.rightMotor.forward();

		}
	}

	@Override
	public int readUSDistance() {
		return this.distance;
	}
}