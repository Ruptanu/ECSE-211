package ca.mcgill.ecse211.lab4;

public class UltrasonicLocalizer extends Thread {
  enum Type {
    FALLING_EDGE, RISING_EDGE
  };

  private static final int D = 30;
  private static final int K = 5;

  private Odometer odometer;

  private Navigator navigator;

  boolean rotating = true;

  private Type type;

  private WallDetector wallDetector;

  public UltrasonicLocalizer(Odometer odometer, Navigator navigator) {
    this.odometer = odometer;

    this.navigator = navigator;

    wallDetector = new WallDetector("S2");
  }


  @Override
  public void run() {
    double firstAngle = 0;
    double secondAngle = 0;

    wallDetector.calibrateSensor();

    if (type == Type.FALLING_EDGE) {
      // Rotate right until there is no more wall
      rotate(false, false);

      // Rotate right until there is a wall
      rotate(true, false);
      // Register the falling edge
      firstAngle = correctAngleChange(odometer.getTheta());

      // Rotates left until there is no more wall
      rotate(false, true);
      // Rotate left until there is a wall
      rotate(true, true);
      // Register the other falling edge
      secondAngle = correctAngleChange(odometer.getTheta());

      navigator.stopMotors();
    } else {
      // Rotate right until there is a wall
      rotate(true, false);
      // Rotate right until there is no more wall
      rotate(false, false);
      // Register the rising edge
      firstAngle = correctAngleChange(odometer.getTheta());
      // Rotates left until there is a wall
      rotate(true, true);
      // Rotate left until there is no more wall
      rotate(false, true);
      // Register the other rising edge
      secondAngle = correctAngleChange(odometer.getTheta());

      navigator.stopMotors();
    }

    double angleChange;

    // Determine the angle change according to the method used
    if (type == Type.FALLING_EDGE) {
      if (firstAngle > secondAngle) {
        angleChange = correctAngleChange(45 - (firstAngle + secondAngle) / 2);
      } else {
        angleChange = correctAngleChange(225 - (firstAngle + secondAngle) / 2);
      }
    } else {
      if (firstAngle < secondAngle) {
        angleChange = correctAngleChange(45 - (firstAngle + secondAngle) / 2);
      } else {
        angleChange = correctAngleChange(225 - (firstAngle + secondAngle) / 2);
      }
    }

    double newAngle = correctAngleChange(odometer.getTheta() + angleChange);

    odometer.setTheta(newAngle);

    navigator.rotateTo(0);

  }

  /** Rotates the robot until it sees or does not see a wall */
  private void rotate(boolean untilWall, boolean left) {
    if (untilWall) {
      while (true) {
        int sample = wallDetector.getSample();
        navigator.rotate(left);
        // If a wall is detected, break out of the loop and return
        if (sample < D - K) {
          return;
        }
      }
    } else {
      while (true) {
        int sample = wallDetector.getSample();
        navigator.rotate(left);
        // If a wall is not detected, break out of the loop and return
        if (sample > D + K) {
          return;
        }
      }
    }
  }

  /** Ensures the given angle is always between -180 to 180 */
  private static double correctAngleChange(double angle) {
    if (angle > 180) {
      return angle - 360;
    } else if (angle < -180) {
      return angle + 360;
    } else {
      return angle;
    }
  }

  /** Sets what type of edge detection to be done */
  public void setType(Type type) {
    this.type = type;
  }
}
