package ca.mcgill.ecse211.lab4;

import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class Navigator {
  private EV3LargeRegulatedMotor leftMotor;
  private EV3LargeRegulatedMotor rightMotor;

  private Odometer odometer;

  private final double WHEEL_RADIUS;
  private final double TRACK;

  private int forwardSpeed;
  private int backwardSpeed;
  private int rotateSpeed;

  private boolean correctAngle = false;


  private static final double PERM_ERROR = 1;
  private static final double PERM_ERROR_SQUARED = PERM_ERROR * PERM_ERROR;

  public Navigator(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
      double wheelRadius, double track, int forwardSpeed, int backwardSpeed, int rotateSpeed,
      Odometer odometer) {
    this.leftMotor = leftMotor;
    this.rightMotor = rightMotor;

    this.odometer = odometer;

    WHEEL_RADIUS = wheelRadius;
    TRACK = track;

    this.forwardSpeed = forwardSpeed;
    this.backwardSpeed = backwardSpeed;
    this.rotateSpeed = rotateSpeed;

    // reset the motors
    for (EV3LargeRegulatedMotor motor : new EV3LargeRegulatedMotor[] {leftMotor, rightMotor}) {
      motor.stop();
      motor.setAcceleration(500);
    }
  }

  /** Travels to the point (x,y) */
  public void travelTo(double x, double y) {
    while (true) {

      double dX = x - odometer.getX();
      double dY = y - odometer.getY();

      if (!correctAngle) {
        rotateTo(determineAngle(dX, dY));
        correctAngle = true;
      }

      moveForward(forwardSpeed);

      if ((dX * dX + dY * dY) < PERM_ERROR_SQUARED) {
        stopMotors();
        return;
      }
    }
  }

  /** Rotates robot to given angle in degrees */
  public void rotateTo(double degrees) {
    // Set motor speed
    leftMotor.setSpeed(rotateSpeed);
    rightMotor.setSpeed(rotateSpeed);

    // Determine angle change
    double angleChange = degrees - odometer.getTheta();

    // Ensure smallest angle change is performed
    angleChange = correctAngleChange(angleChange);

    // Determines the wheel rotation based on angle change
    int convertedAngle = convertAngle(WHEEL_RADIUS, TRACK, angleChange);

    // Rotates robot
    leftMotor.rotate(convertedAngle, true);
    rightMotor.rotate(-convertedAngle, false);
  }

  /** Rotates robot to the left if true and right if false */
  public void rotate(boolean left) {
    leftMotor.setSpeed(rotateSpeed);
    rightMotor.setSpeed(rotateSpeed);
    if (left) {
      leftMotor.backward();
      rightMotor.forward();
    } else {
      leftMotor.forward();
      rightMotor.backward();
    }
  }

  /** Ensures the given angle is always between -180 to 180 */
  private static double correctAngleChange(double angle) {
    if (angle > 180) {
      return angle - 360;
    } else if (angle < -180) {
      return angle + 360;
    } else {
      return angle;
    }
  }

  /** Converts robot displacement into wheel distance */
  private static int convertDistance(double radius, double distance) {
    return (int) ((180.0 * distance) / (Math.PI * radius));
  }

  /** Converts the robot angle change into wheel distance */
  private static int convertAngle(double radius, double width, double angle) {
    return convertDistance(radius, Math.PI * width * angle / 360.0);
  }

  /** Converts xy coordinates into an angle while keeping track of initial signs */
  private static float determineAngle(double x, double y) {
    if (x == 0 && y == 0) {
      return 0;
    } else if (x == 0 && y > 0) {
      return 0;
    } else if (x == 0 && y < 0) {
      return 180;
    } else if (x > 0 && y == 0) {
      return 90;
    } else if (x < 0 && y == 0) {
      return -90;
    } else if (x < 0 && y < 0) {
      return (float) Math.atan(x / y) * 57.3f + 180;
    } else if (x > 0 && y < 0) {
      return (float) Math.atan(x / y) * 57.3f + 180;
    } else {
      return (float) Math.atan(x / y) * 57.3f;
    }
  }

  /** Both wheels are set to forward at forwardSpeed */
  public void moveForward(int forwardSpeed) {
    leftMotor.setSpeed(forwardSpeed);
    rightMotor.setSpeed(forwardSpeed);
    leftMotor.forward();
    rightMotor.forward();
  }

  /** Both wheels are set to forward with preset speed */
  public void moveForward() {
    leftMotor.setSpeed(forwardSpeed);
    rightMotor.setSpeed(forwardSpeed);
    leftMotor.forward();
    rightMotor.forward();
  }

  /** Both wheels are set to backward at backwardSpeed */
  public void moveBackward(int backwardSpeed) {
    leftMotor.setSpeed(backwardSpeed);
    rightMotor.setSpeed(backwardSpeed);
    leftMotor.backward();
    rightMotor.backward();
  }

  /** Both wheels are set to backward with preset speed */
  public void moveBackward() {
    leftMotor.setSpeed(backwardSpeed);
    rightMotor.setSpeed(backwardSpeed);
    leftMotor.backward();
    rightMotor.backward();
  }

  /** Stops both motors simultaneously */
  public void stopMotors() {
    leftMotor.stop(true);
    rightMotor.stop();
  }

  /** The following are the getter-setter methods for various parameters in Navigator */

  /** Returns leftMotor object */
  public EV3LargeRegulatedMotor getLeftMotor() {
    return leftMotor;
  }

  /** Sets the leftMotor object */
  public void setLeftMotor(EV3LargeRegulatedMotor leftMotor) {
    this.leftMotor = leftMotor;
  }

  /** Returns the rightMotor object */
  public EV3LargeRegulatedMotor getRightMotor() {
    return rightMotor;
  }

  /** Sets the rightMotor object */
  public void setRightMotor(EV3LargeRegulatedMotor rightMotor) {
    this.rightMotor = rightMotor;
  }

  /** Returns the forward speed */
  public int getForwardSpeed() {
    return forwardSpeed;
  }

  /** Sets the forward speed */
  public void setForwardSpeed(int forwardSpeed) {
    this.forwardSpeed = forwardSpeed;
  }

  /** Returns the backward speed */
  public int getBackwardSpeed() {
    return backwardSpeed;
  }

  /** Sets the backward speed */
  public void setBackwardSpeed(int backwardSpeed) {
    this.backwardSpeed = backwardSpeed;
  }

  /** Returns the rotate speed */
  public int getRotateSpeed() {
    return rotateSpeed;
  }

  /** Sets the rotate speed */
  public void setRotateSpeed(int rotateSpeed) {
    this.rotateSpeed = rotateSpeed;
  }
}
