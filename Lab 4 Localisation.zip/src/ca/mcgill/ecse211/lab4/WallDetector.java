package ca.mcgill.ecse211.lab4;

import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

public class WallDetector {
  private static UltrasonicPoller usPoller;

  int filterControl;
  private final int FILTER_OUT = 20;
  int lastValidSample;

  public WallDetector(String sensorPort) {
    @SuppressWarnings("resource")
    SensorModes usSensor = new EV3UltrasonicSensor(LocalEV3.get().getPort(sensorPort));
    SampleProvider usDistance = usSensor.getMode("Distance");
    float[] usData = new float[usDistance.sampleSize()];

    usPoller = new UltrasonicPoller(usDistance, usData);
  }

  public int getSample() {
    try {
      Thread.sleep(50);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    int sample = usPoller.fetchSample();

    int filteredSample = 0;

    // Reused filtering code from previous labs
    if (sample >= 255 && filterControl < FILTER_OUT) {
      // bad value, do not set the distance var, however do increment the
      // filter value
      filterControl++;
      return lastValidSample;
    } else if (sample >= 255) {
      // We have repeated large values, so there must actually be nothing
      // there: leave the distance alone
      filteredSample = sample;
    } else {
      // distance went below 255: reset filter and leave
      // distance alone.
      filterControl = 0;
      filteredSample = sample;
    }

    lastValidSample = filteredSample;

    return filteredSample;
  }

  /** Calibrates the sensor */
  public void calibrateSensor() {
    // Reads a few values so that if there is nothing in front of it, the filter does not
    // automatically discard it as 0
    for (int i = 0; i < 30; i++) {
      getSample();
    }
  }


}
