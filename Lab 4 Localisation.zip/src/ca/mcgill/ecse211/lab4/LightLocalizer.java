package ca.mcgill.ecse211.lab4;

public class LightLocalizer extends Thread {
  private Odometer odometer;
  private Navigator navigator;
  private LineDetector detector;

  private static final double D = 10.5;


  public LightLocalizer(Odometer odometer, Navigator navigator) {
    this.odometer = odometer;
    this.navigator = navigator;

    detector = new LineDetector("S3");
  }

  @Override
  public void run() {
    // Calibrate the sensor
    detector.calibrateSensor();

    // Rotate the robot to approximately 45 degrees
    navigator.rotateTo(45);

    // Move forward until it sees a line
    navigator.moveForward();
    while (true) {
      if (detector.hasLine()) {
        break;
      }
    }

    // Once it has seen a line, move backward for 4 seconds and stop
    navigator.moveBackward();
    try {
      Thread.sleep(4000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    navigator.stopMotors();

    // Keeps track of which line has been seen
    int lineCounter = 0;

    // Used to store the angle when a line is detected
    double[] angleArray = new double[4];

    // Rotate left until four lines have been detected
    navigator.rotate(true);
    while (true) {
      if (detector.hasLine()) {
        angleArray[lineCounter] = odometer.getTheta();
        lineCounter++;
      }
      if (lineCounter >= 4) {
        break;
      }
    }
    navigator.stopMotors();

    // Determine the new x, y, and angle change
    double x = -1 * D * Math.cos(Math.toRadians((angleArray[0] - angleArray[2]) / 2.0));
    double y = -1 * D * Math.cos(Math.toRadians((angleArray[1] - angleArray[3]) / 2.0));
    double angleChange = (angleArray[1] - angleArray[3]) / 2 + 270 - angleArray[0];

    // Set the new values on the odometer
    odometer.setX(x);
    odometer.setY(y);
    odometer.setTheta(correctAngleChange(odometer.getTheta() + angleChange));

    // Navigate to the correct values
    navigator.travelTo(0, 0);
    navigator.rotateTo(0);
  }

  /** Ensures the given angle is always between -180 to 180 */
  private static double correctAngleChange(double angle) {
    if (angle > 180) {
      return angle - 360;
    } else if (angle < -180) {
      return angle + 360;
    } else {
      return angle;
    }
  }
}
