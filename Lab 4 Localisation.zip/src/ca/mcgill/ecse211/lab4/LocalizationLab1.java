package ca.mcgill.ecse211.lab4;

import lejos.hardware.Button;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class LocalizationLab1 {

  public static final double WHEEL_RADIUS = 2.15;
  public static final double TRACK = 9.85; // 10.2
  public static final int ROTATE_SPEED = 70;
  public static final int FORWARD_SPEED = 100;

  public static Odometer odometer;

  public static Navigator navigator;

  private static final EV3LargeRegulatedMotor leftMotor =
      new EV3LargeRegulatedMotor(LocalEV3.get().getPort("A"));

  private static final EV3LargeRegulatedMotor rightMotor =
      new EV3LargeRegulatedMotor(LocalEV3.get().getPort("D"));

  public static void main(String[] args) {
    final TextLCD t = LocalEV3.get().getTextLCD();

    odometer = new Odometer(leftMotor, rightMotor);
    OdometryDisplay odometryDisplay = new OdometryDisplay(odometer, t);

    navigator = new Navigator(leftMotor, rightMotor, WHEEL_RADIUS, TRACK, FORWARD_SPEED,
        FORWARD_SPEED, ROTATE_SPEED, odometer);

    UltrasonicLocalizer usLocal = new UltrasonicLocalizer(odometer, navigator);
    LightLocalizer liLocal = new LightLocalizer(odometer, navigator);


    t.clear();

    t.drawString("       |        ", 0, 0);
    t.drawString(" Rising|Falling ", 0, 1);
    t.drawString(" Edge  |  Edge  ", 0, 2);
    t.drawString("  <<   |   >>   ", 0, 3);
    t.drawString("       |        ", 0, 4);

    int buttonChoice = Button.waitForAnyPress();

    if (buttonChoice == Button.ID_LEFT) {
      usLocal.setType(UltrasonicLocalizer.Type.RISING_EDGE);
    } else if (buttonChoice == Button.ID_RIGHT) {
      usLocal.setType(UltrasonicLocalizer.Type.FALLING_EDGE);
    }



    t.clear();
    odometer.start();
    odometryDisplay.start();
    usLocal.start();
    Button.waitForAnyPress();
    t.clear();
    liLocal.start();


    while (Button.waitForAnyPress() != Button.ID_ESCAPE);
    System.exit(0);
  }
}
