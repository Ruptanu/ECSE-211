package ca.mcgill.ecse211.lab4;

import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.robotics.SampleProvider;

public class LineDetector {
  private static final long CORRECTION_PERIOD = 10;

  private SampleProvider colorSensor;
  private float[] colorSample;

  private float[] recentValues;
  private int valueSize = 25;
  private float prevAve = 0;
  private int filterPos = 0;
  private int filterWidth = 5;

  private float threshold = 0.2f;

  private int calibrationCounter = 0;
  private int calibDelay = 60;

  private int stableCounter = 0;
  private int stableDelay = 100;

  private long correctionStart;
  private long correctionEnd;

  @SuppressWarnings("resource")
  public LineDetector(String sensorPort) {
    colorSensor = new EV3ColorSensor(LocalEV3.get().getPort(sensorPort)).getRedMode();

    colorSample = new float[colorSensor.sampleSize()];

    recentValues = new float[valueSize];
  }

  public boolean hasLine() {
    boolean hasLine = false;

    correctionStart = System.currentTimeMillis();

    colorSensor.fetchSample(colorSample, 0);

    float curSample = colorSample[0] * 100;

    float ave =
        prevAve + (curSample - recentValues[getFilterPos(-filterWidth)]) / ((float) filterWidth);

    if (calibrationCounter > calibDelay) {
      if (Math.abs(recentValues[filterPos] - ave) > (threshold * ave)
          && stableCounter > stableDelay) {
        LocalEV3.get().getAudio().systemSound(0);
        hasLine = true;
        stableCounter = 0;
      } else {
        stableCounter++;
        if (stableCounter > stableDelay * 4) {
          stableCounter = stableDelay * 4;
        }
      }
    } else {
      calibrationCounter++;
    }


    recentValues[filterPos] = ave;

    prevAve = ave;

    // Increments filterPos by 1 and loops it at valueSize
    filterPos = getFilterPos(1);



    // this ensure the odometry correction occurs only once every period
    correctionEnd = System.currentTimeMillis();
    if (correctionEnd - correctionStart < CORRECTION_PERIOD) {
      try {
        Thread.sleep(CORRECTION_PERIOD - (correctionEnd - correctionStart));
      } catch (InterruptedException e) {
        // there is nothing to be done here because it is not
        // expected that the odometry correction will be
        // interrupted by another thread
      }
    }

    return hasLine;
  }

  public int getFilterPos(int offSet) {
    int nextValue = filterPos + offSet;
    if (nextValue < 0) {
      nextValue += valueSize;
    }
    return nextValue % valueSize;
  }

  /** Calibrates the sensor */
  public void calibrateSensor() {
    // Does a few readings so that the filtering has enough values to recognize line changes
    for (int i = 0; i < 2 * calibDelay; i++) {
      hasLine();
    }
  }
}
