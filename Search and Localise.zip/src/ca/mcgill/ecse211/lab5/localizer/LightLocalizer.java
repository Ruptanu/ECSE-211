package ca.mcgill.ecse211.lab5.localizer;

import ca.mcgill.ecse211.lab5.odometer.Odometer;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.SensorMode;

public class LightLocalizer {
	private final double SENSOR_OFFSET = -13;
	private final double TRACK;
	private final double WHEEL_RADIUS;

	private final Odometer odometer;
	private final EV3LargeRegulatedMotor leftMotor;
	private final EV3LargeRegulatedMotor rightMotor;
	private final EV3ColorSensor colorSensor = new EV3ColorSensor(LocalEV3.get().getPort("S1"));
	private final SensorMode sensorMode = colorSensor.getRGBMode();

	public LightLocalizer(Odometer odometer, EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor, double track, double wheelRadius) {
		this.odometer = odometer;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		this.TRACK = track;
		this.WHEEL_RADIUS = wheelRadius;
	}

	/**
	 * Moves the robot from an arbitrary position in the corner, to the origin
	 * position (while maintaining direction)
	 */
	public void localize() {
		leftMotor.setSpeed(100);
		rightMotor.setSpeed(100);
		
		// Align with the back wall
		leftMotor.rotate(convertDistance(WHEEL_RADIUS, -15), true);
		rightMotor.rotate(convertDistance(WHEEL_RADIUS, -15), false);

		while (!overBlack()) {
			// Move forwards until line is detected
			leftMotor.forward();
			rightMotor.forward();
		}

		// Stop moving on the black line
		leftMotor.stop(true);
		rightMotor.stop(false);

		// Correct the odometer
		odometer.setY(-SENSOR_OFFSET);

		// Turn toward the next line
		leftMotor.setSpeed(150);
		rightMotor.setSpeed(150);
		leftMotor.rotate(convertAngle(WHEEL_RADIUS, TRACK, 90), true);
		rightMotor.rotate(-convertAngle(WHEEL_RADIUS, TRACK, 90), false);

		// Move to the next line
		leftMotor.setSpeed(100);
		rightMotor.setSpeed(100);
		do {
			// Move forwards until line is detected
			leftMotor.forward();
			rightMotor.forward();
		} while (!overBlack());

		// Stop moving on the black line
		leftMotor.stop(true);
		rightMotor.stop(false);

		// Correct the odometer
		odometer.setX(-SENSOR_OFFSET);
		
		leftMotor.setSpeed(150);
		rightMotor.setSpeed(150);

		// Move onto the line (accounting for sensor offset)
		leftMotor.rotate(convertDistance(WHEEL_RADIUS, SENSOR_OFFSET), true);
		rightMotor.rotate(convertDistance(WHEEL_RADIUS, SENSOR_OFFSET), false);

		// Turn to face the correct direction
		leftMotor.rotate(-convertAngle(WHEEL_RADIUS, TRACK, 90), true);
		rightMotor.rotate(convertAngle(WHEEL_RADIUS, TRACK, 90), false);

		// Move onto the origin (accounting for sensor offset)
		leftMotor.rotate(convertDistance(WHEEL_RADIUS, SENSOR_OFFSET), true);
		rightMotor.rotate(convertDistance(WHEEL_RADIUS, SENSOR_OFFSET), false);

		leftMotor.stop(true);
		rightMotor.stop(false);
	}
	
	/**
	 * Determine whether the light sensor detects a line
	 */
	private boolean overBlack() {
		final float brightnessTrigger = 0.14f;
		float[] colour = new float[sensorMode.sampleSize()];

		// Sense RGB light values
		sensorMode.fetchSample(colour, 0);
		float red = colour[0];
		float green = colour[1];
		float blue = colour[2];
		float brightness = red + green + blue;
		boolean overBlack = brightness < brightnessTrigger;
		
		return overBlack;
	}

	/**
	 * This method allows the conversion of a distance to the total rotation of
	 * each wheel need to cover that distance.
	 * 
	 * @param radius
	 * @param distance
	 * @return
	 */
	private static int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}

	private static int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius, Math.PI * width * angle / 360.0);
	}
}
