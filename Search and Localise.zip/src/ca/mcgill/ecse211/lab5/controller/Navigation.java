package ca.mcgill.ecse211.lab5.controller;

import ca.mcgill.ecse211.lab5.odometer.Odometer;
import lejos.hardware.motor.EV3LargeRegulatedMotor;

/**
 * This class is used to drive the robot on the demo floor.
 */
public class Navigation {
	private static final int MOVE_SPEED = 150;
	private static final int ROTATE_SPEED = 75;
	private static final double TILE_SIZE = 30.48;
	private double WHEEL_RADIUS;
	private double TRACK;

	private final Odometer odometer;
	private final EV3LargeRegulatedMotor leftMotor;
	private final EV3LargeRegulatedMotor rightMotor;

	public Navigation(Odometer odometer, EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor, double track, double wheelRadius) {
		this.odometer = odometer;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		this.WHEEL_RADIUS = wheelRadius;
		this.TRACK = track;
	}

	/**
	 * Controls the robot to travel to the specified map coordinates via the shortest route and minimal angle
	 * @param x x-coordinate to travel to (range 0-2)
	 * @param y y-coordinate to travel to (range 0-2)
	 */
	public void travelTo(double x, double y) {
		// Determine the odometer position to travel to in cm
		double destinationX = x * TILE_SIZE;
		double destinationY = y * TILE_SIZE;

		// Calculate the distance and direction to the destination
		double[] xyt = odometer.getXYT();
		double currentX = xyt[0];
		double currentY = xyt[1];
		double distance = this.distance(currentX, currentY, destinationX, destinationY);
		double direction = this.direction(currentX, currentY, destinationX, destinationY);

		// Turn to face the waypoint
		turnTo(direction);
		
		// Move to the waypoint
		leftMotor.setSpeed(MOVE_SPEED);
		rightMotor.setSpeed(MOVE_SPEED);
		leftMotor.rotate(convertDistance(WHEEL_RADIUS, distance), true);
		rightMotor.rotate(convertDistance(WHEEL_RADIUS, distance), false);
	}

	/**
	 * Turns the robot to point in a given direction based on the odometer
	 * @param theta Angle to point towards
	 */
	public void turnTo(double theta) {
		// Calculate speed and direction left to travel
		double[] xyt = odometer.getXYT();
		double currentTheta = xyt[2];
		double angleDifference = angleDifference(currentTheta, theta);
		
		// Turn to face the waypoint
		leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
		
		// Determine direction to turn for minimum angle (left or right)
		if ((theta - currentTheta + 360) % 360 > 180) {
			leftMotor.rotate(convertAngle(WHEEL_RADIUS, TRACK, angleDifference), true);
			rightMotor.rotate(-convertAngle(WHEEL_RADIUS, TRACK, angleDifference), false);
		} else {
			leftMotor.rotate(-convertAngle(WHEEL_RADIUS, TRACK, angleDifference), true);
			rightMotor.rotate(convertAngle(WHEEL_RADIUS, TRACK, angleDifference), false);
		}
	}

	/**
	 * Calculate the distance between two points
	 * @param x1
	 * @param y1
	 * @param x2
	 * @param y2
	 * @return Distance between points
	 */
	private double distance(double x1, double y1, double x2, double y2) {
		return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
	}

	/**
	 * Calculate the angle between two points
	 * @param x1
	 * @param y1
	 * @param x2
	 * @param y2
	 * @return Angle between points
	 */
	private double direction(double x1, double y1, double x2, double y2) {
		double direction = Math.toDegrees(Math.atan2(y2 - y1, x2 - x1));
		return (direction + 360) % 360;
	}

	/**
	 * Calculate the absolute difference between two angles
	 * @param theta1
	 * @param theta2
	 * @return Delta angle
	 */
	private double angleDifference(double theta1, double theta2) {
		double dTheta = Math.abs(theta2 - theta1);
		return Math.min(dTheta, 360 - dTheta);
	}
	
	/**
	 * This method allows the conversion of a distance to the total rotation of
	 * each wheel need to cover that distance.
	 * 
	 * @param radius
	 * @param distance
	 * @return
	 */
	private static int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}

	private static int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius, Math.PI * width * angle / 360.0);
	}
}
