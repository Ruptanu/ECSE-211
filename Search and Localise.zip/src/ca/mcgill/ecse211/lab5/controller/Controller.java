package ca.mcgill.ecse211.lab5.controller;

import ca.mcgill.ecse211.lab5.localizer.*;
import ca.mcgill.ecse211.lab5.odometer.*;
import lejos.hardware.Button;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.motor.NXTRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

public class Controller {
	// Motor Objects, and Robot related parameters
	private static final EV3LargeRegulatedMotor leftMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("A"));
	private static final EV3LargeRegulatedMotor rightMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("D"));
	private static final NXTRegulatedMotor midMotor = new NXTRegulatedMotor(LocalEV3.get().getPort("C"));
	private static final Port usPort = LocalEV3.get().getPort("S3");
	private static final TextLCD lcd = LocalEV3.get().getTextLCD();
	public static Display display;

	// Initial conditions
	public static final int LLx = 2;
	public static final int LLy = 3;
	public static final int URx = 6;
	public static final int URy = 7;
	public static final int TB = 2;
	public static final int SC = 0;

	public static final double TRACK = 17.1;
	public static final double WHEEL_RADIUS = 2.2;
	public static final double TILE_SIZE = 30.48;

	public static void main(String[] args) throws OdometerExceptions, InterruptedException {
		int buttonChoice;

		// Setup ultrasonic sensor
		@SuppressWarnings("resource") // Because we don't bother to close this resource
		SensorModes usSensor = new EV3UltrasonicSensor(usPort); // usSensor is the instance
		SampleProvider usDistance = usSensor.getMode("Distance"); // usDistance provides samples from this instance
		float[] usData = new float[usDistance.sampleSize()]; // usData is the buffer in which data are returned

		// Initialize components
		final Odometer odometer = new Odometer(leftMotor, rightMotor, TRACK, WHEEL_RADIUS);
		final UltrasonicLocalizer usLocalizer = new UltrasonicLocalizer(usDistance, usData, odometer, leftMotor, rightMotor, TRACK, WHEEL_RADIUS);
		final LightLocalizer lightLocalizer = new LightLocalizer(odometer, leftMotor, rightMotor, TRACK, WHEEL_RADIUS);
		final Navigation navigation = new Navigation(odometer, leftMotor, rightMotor, TRACK, WHEEL_RADIUS);
		final Searcher searcher = new Searcher(usDistance, usData, odometer, navigation, leftMotor, rightMotor, midMotor);
		display = new Display(lcd, odometer);

		// Wait for button press to start program
		do {
			lcd.clear();
			lcd.drawString(" Press R to run	    ", 0, 0);
			lcd.drawString(" Press L for colour ", 0, 1);
			buttonChoice = Button.waitForAnyPress(); // Record choice (left or right press)
		} while (buttonChoice != Button.ID_LEFT && buttonChoice != Button.ID_RIGHT);

		lcd.clear();
		
		// Start display thread
		Thread odoDisplayThread = new Thread(display);
		odoDisplayThread.start();

		// Only run the main program if Right was pressed
		if (buttonChoice == Button.ID_RIGHT) {
			// Start odometer thread
			Thread odoThread = new Thread(odometer);
			odoThread.start();
	
			// Start localization thread
			Thread localizationThread = new Thread() {
				public void run() {
					// Reset the motors
					for (EV3LargeRegulatedMotor motor : new EV3LargeRegulatedMotor[] {leftMotor, rightMotor}) {
						motor.stop();
						motor.setAcceleration(1000);
					}
					
					// Localize angle
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {}
					usLocalizer.localize();
					
					// Localize position
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {}
					lightLocalizer.localize();
	
					// Update odometer depending on starting corner
					switch (SC) {
						case 0:
							odometer.setX(1 * TILE_SIZE);
							odometer.setY(1 * TILE_SIZE);
							odometer.setTheta(90);
							break;
						case 1:
							odometer.setX(7 * TILE_SIZE);
							odometer.setY(1 * TILE_SIZE);
							odometer.setTheta(180);
							break;
						case 2:
							odometer.setX(7 * TILE_SIZE);
							odometer.setY(7 * TILE_SIZE);
							odometer.setTheta(270);
							break;
						case 3:
							odometer.setX(1 * TILE_SIZE);
							odometer.setY(7 * TILE_SIZE);
							odometer.setTheta(0);
							break;
					}
					
					// Search for blocks
					searcher.search();
				}
			};
			localizationThread.start();
		}

		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {}

		// Wait for button press to end program
		while (Button.waitForAnyPress() != Button.ID_ESCAPE) {
		}
		
		System.exit(0);
	}
}
