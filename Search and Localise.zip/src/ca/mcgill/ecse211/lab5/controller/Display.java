package ca.mcgill.ecse211.lab5.controller;

import java.text.DecimalFormat;

import ca.mcgill.ecse211.lab5.odometer.Odometer;
import ca.mcgill.ecse211.lab5.odometer.OdometerExceptions;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.SensorMode;

/**
 * This class is used to display the content of the odometer variables (x, y,
 * Theta)
 */
public class Display implements Runnable {
	private TextLCD lcd;
	private Odometer odometer;
	private double[] position;
	private final long DISPLAY_PERIOD = 25;
	private long timeout = Long.MAX_VALUE;
	private final EV3ColorSensor colorSensor = new EV3ColorSensor(LocalEV3.get().getPort("S4"));
	private final SensorMode sensorMode = colorSensor.getRGBMode();

	/**
	 * This is the class constructor
	 * 
	 * @param odoData
	 * @throws OdometerExceptions
	 */
	public Display(TextLCD lcd, Odometer odometer) throws OdometerExceptions {
		this.lcd = lcd;
		this.odometer = odometer;
	}

	/**
	 * This is the overloaded class constructor
	 * 
	 * @param odoData
	 * @throws OdometerExceptions
	 */
	public Display(TextLCD lcd, long timeout, Odometer odometer) throws OdometerExceptions {
		this.timeout = timeout;
		this.lcd = lcd;
		this.odometer = odometer;
	}

	public void run() {

		lcd.clear();

		long updateStart, updateEnd;
		long tStart = System.currentTimeMillis();

		do {
			updateStart = System.currentTimeMillis();

			// Retrieve x, y and Theta information
//			position = odometer.getXYT();

			// Print x,y, and theta information
//			DecimalFormat numberFormat = new DecimalFormat("######0.00");
//			lcd.drawString("X: " + numberFormat.format(position[0]), 0, 0);
//			lcd.drawString("Y: " + numberFormat.format(position[1]), 0, 1);
//			lcd.drawString("T: " + numberFormat.format(position[2]), 0, 2);
			
			int colour = getColour();
			
			if (colour != -1) {
				lcd.drawString("Object Detected", 0, 0);
				
				switch (colour) {
					case 1:
						lcd.drawString("Red", 0, 1);
						break;
					case 2:
						lcd.drawString("Blue", 0, 1);
						break;
					case 3:
						lcd.drawString("Yellow", 0, 1);
						break;
					case 4:
						lcd.drawString("White", 0, 1);
						break;
				}
			} else {
				lcd.clear();
			}

			// this ensures that the data is updated only once every period
			updateEnd = System.currentTimeMillis();
			if (updateEnd - updateStart < DISPLAY_PERIOD) {
				try {
					Thread.sleep(DISPLAY_PERIOD - (updateEnd - updateStart));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		} while ((updateEnd - tStart) <= timeout);

	}
	
	public int getColour() {
		float[] colour = new float[sensorMode.sampleSize()];

		// Sense RGB light values
		sensorMode.fetchSample(colour, 0);
		float red = colour[0];
		float green = colour[1];
		float blue = colour[2];
		
		if (red < 0.02 && green < 0.02) {
			return -1; // No block detected
		} else if (red > 0.1 && blue < 0.02) {
			return 1; // Red
		} else if (red < 0.06) {
			return 2; // Blue
		} else if (red > 0.25 && blue < 0.04) {
			return 3; // Yellow
		} else if (red > 0.25 && blue < 0.3) {
			return 4; // White
		} else {
			return -1; // No block detected
		}
	}
}
