package ca.mcgill.ecse211.lab3;

import lejos.hardware.Button;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

public class NavigationLab {
  private static final Port usPort = LocalEV3.get().getPort("S2");
  public static UltrasonicPoller usPoller;

  private static final EV3LargeRegulatedMotor leftMotor =
      new EV3LargeRegulatedMotor(LocalEV3.get().getPort("A"));

  private static final EV3LargeRegulatedMotor rightMotor =
      new EV3LargeRegulatedMotor(LocalEV3.get().getPort("D"));

  public static final double WHEEL_RADIUS = 2.15;
  public static final double TRACK = 9.85; // TRACK value tweaked to make robot return approximately
                                           // to its starting
                                          

  public static final int SQUARE_SIZE = 30;
  public static int[] path = {0, 2, 2, 2, 2, 1, 1, 0, 0, 0};
  public static Odometer odometer;

  public static void main(String[] args) {
    int buttonChoice;

    // Initialize the necessary objects
    final TextLCD t = LocalEV3.get().getTextLCD();
    odometer = new Odometer(leftMotor, rightMotor);
    OdometryDisplay odometryDisplay = new OdometryDisplay(odometer, t);

    @SuppressWarnings("resource") // Because we don't bother to close this resource
    SensorModes usSensor = new EV3UltrasonicSensor(usPort); // usSensor is the instance
    SampleProvider usDistance = usSensor.getMode("Distance"); // usDistance provides samples from

    float[] usData = new float[usDistance.sampleSize()]; // usData is the buffer in which data are

    usPoller = new UltrasonicPoller(usDistance, usData);

    // clear the display
    t.clear();

    // ask the user whether the motors should drive in a square or float
    t.drawString("< Left | Right >", 0, 0);
    t.drawString("  No   | with   ", 0, 1);
    t.drawString(" avoi- | avoi-  ", 0, 2);
    t.drawString(" dance | dance  ", 0, 3);
    t.drawString("       |        ", 0, 4);

    buttonChoice = Button.waitForAnyPress();

    // Start odometry
    odometer.start();
    odometryDisplay.start();

    // Enable obstacle avoidance
    if (buttonChoice == Button.ID_RIGHT) { // Other button presses will default
      NavigationDriver.isAvoid = true;     // to "No avoidance"
    }

    // spawn a new Thread to avoid NavigationDriver.drive() from blocking
    (new Thread() {
      public void run() {
        NavigationDriver.drive(leftMotor, rightMotor, WHEEL_RADIUS, WHEEL_RADIUS, TRACK, path,
            SQUARE_SIZE);
      }
    }).start();


    while (Button.waitForAnyPress() != Button.ID_ESCAPE);
    System.exit(0);
  }
}
