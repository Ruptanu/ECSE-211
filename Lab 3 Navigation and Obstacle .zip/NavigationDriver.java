package ca.mcgill.ecse211.lab3;

import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class NavigationDriver {
  private static final int FORWARD_SPEED = 225;
  private static final int ROTATE_SPEED = 120; 


  private static final int BAND_CENTER = 15;

  private static Odometer odometer;
  private static final double PERM_ERROR = 1;
  private static final double PERM_ERROR_SQUARED = PERM_ERROR * PERM_ERROR;

  private static EV3LargeRegulatedMotor rightMotor;
  private static EV3LargeRegulatedMotor leftMotor;

  static boolean correctAngle = false;

  static boolean isAvoid = false;

  /** Drive the robot through a given path */
  public static void drive(EV3LargeRegulatedMotor lMotor, EV3LargeRegulatedMotor rMotor,
      double leftRadius, double rightRadius, double width, int[] path, int squareSize) {

    odometer = NavigationLab.odometer;

    rightMotor = rMotor;
    leftMotor = lMotor;


    // reset the motors
    for (EV3LargeRegulatedMotor motor : new EV3LargeRegulatedMotor[] {leftMotor, rightMotor}) {
      motor.stop();
      motor.setAcceleration(500);
    }

    // wait 2 seconds
    sleep(2000);

    // Makes sure the array is of proper length
    if ((path.length) % 2 != 0) {
      int[] tempArray = new int[path.length - 1];
      System.arraycopy(path, 0, tempArray, 0, path.length - 1);
      path = tempArray;
    }

    // Travels to each point on its trajectory
    for (int i = 0; i < path.length; i += 2) {
      float x = path[i] * squareSize;
      float y = path[i + 1] * squareSize;
      correctAngle = false;
      travelTo(x, y);
    }
  }

  /** Travel to a given point x and y */
  public static void travelTo(double x, double y) {
    while (true) {
      if (willCollide() && isAvoid) {
        avoid();
      }

      double dX = x - odometer.getX();
      double dY = y - odometer.getY();

      if (!correctAngle) {
        rotateTo(determineAngle(dX, dY));
        correctAngle = true;
      }

      moveForward(FORWARD_SPEED);

      if ((dX * dX + dY * dY) < PERM_ERROR_SQUARED) {
        stopMotors();
        return;
      }
    }
  }

  /** Adds a trajectory to the robot which avoids an obstacle */
  private static void avoid() {
    // Ensures that once the avoidance is complete, the robot rotate back towards its destination
    correctAngle = false;
    stopMotors();

    // Rotates 55 degrees
    rotateTo(odometer.getTheta() + 55);

    // Moves away from obstacle
    moveForward(FORWARD_SPEED);
    sleep(4000);
    stopMotors();

    // Straightens trajectory
    rotateTo(odometer.getTheta() - 55);
    //stopMotors();

    
    boolean stillBlocked = false;
    
    //Checks periodically if it has cleared the obstacle
    do {
      moveForward(FORWARD_SPEED);
      sleep(2000);
      stopMotors();
      
      rotateTo(odometer.getTheta() - 90);
      if(willCollide()) {
        stillBlocked = true;
      } else {
        stillBlocked = false;
      }
      rotateTo(odometer.getTheta() + 90);
      
    } while(stillBlocked);
  }

  /** Rotates the robot to a given angle */
  private static void rotateTo(double degrees) {
    // Set motor speed
    leftMotor.setSpeed(ROTATE_SPEED);
    rightMotor.setSpeed(ROTATE_SPEED);

    // Determine angle change
    double angleChange = degrees - odometer.getTheta();

    // Ensure smallest angle change is performed
    angleChange = correctAngleChange(angleChange);

    // Determines the wheel rotation based on angle change
    int convertedAngle = convertAngle(NavigationLab.WHEEL_RADIUS, NavigationLab.TRACK, angleChange);

    // Rotates robot
    leftMotor.rotate(convertedAngle, true);
    rightMotor.rotate(-convertedAngle, false);
  }

  /** Converts robot displacement into wheel distance */
  private static int convertDistance(double radius, double distance) {
    return (int) ((180.0 * distance) / (Math.PI * radius));
  }

  /** Converts the robot angle change into wheel distance */
  private static int convertAngle(double radius, double width, double angle) {
    return convertDistance(radius, Math.PI * width * angle / 360.0);
  }

  /** Converts xy coordinates into an angle while keeping track of initial signs */
  private static float determineAngle(double x, double y) {
    if (x == 0 && y == 0) {
      return 0;
    } else if (x == 0 && y > 0) {
      return 0;
    } else if (x == 0 && y < 0) {
      return 180;
    } else if (x > 0 && y == 0) {
      return 90;
    } else if (x < 0 && y == 0) {
      return -90;
    } else if (x < 0 && y < 0) {
      return (float) Math.atan(x / y) * 57.3f + 180;
    } else if (x > 0 && y < 0) {
      return (float) Math.atan(x / y) * 57.3f + 180;
    } else {
      return (float) Math.atan(x / y) * 57.3f;
    }
  }

  /** Ensures the given angle is always between -180 to 180 */
  private static double correctAngleChange(double angle) {
    if (angle > 180) {
      return angle - 360;
    } else if (angle < -180) {
      return angle + 360;
    } else {
      return angle;
    }
  }


  /** The following are utility methods used to increase readability */
  /** Both wheels are set to forward */
  private static void moveForward(int forwardSpeed) {
    leftMotor.setSpeed(forwardSpeed);
    rightMotor.setSpeed(forwardSpeed);
    leftMotor.forward();
    rightMotor.forward();
  }

  /** Stops both motors simultaneously */
  private static void stopMotors() {
    leftMotor.stop(true);
    rightMotor.stop();
  }

  /** Determines if the robot will collide with something in front of it */
  private static boolean willCollide() {
    return NavigationLab.usPoller.fetchSample() < BAND_CENTER;
  }

  private static void sleep(long duration) {
    try {
      Thread.sleep(duration);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }
}
